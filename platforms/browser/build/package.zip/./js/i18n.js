$.i18n.properties({ 
	name: 'Messages', 
	path: 'resources/', 
	mode: 'both',
	language: 'es',
	callback: function(){}
});