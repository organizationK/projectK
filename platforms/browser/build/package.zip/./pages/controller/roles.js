var button1 = "";

$("#button1").button();